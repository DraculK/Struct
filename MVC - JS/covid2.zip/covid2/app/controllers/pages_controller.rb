class PagesController < ApplicationController
    def home
    end
end