

function get_country_data(country) {
    return $.ajax(
        {
            url: "https://covid19-brazil-api.now.sh/api/report/v1/" + country
        }
    )
}

function getCovidData() {
    return $.ajax(
        {
            url: "https://covid19-brazil-api.now.sh/api/report/v1/countries",
            dataType: "json",
        }
    )
}
function getStateCases(data_json) {
    let data = [];
    for (let i=0; i < data_json.length; i++) {
        data.push(data_json[i].cases)
    }
    console.log(data);
    return data
}
function getStateDeaths(data_json) {
    let data = [];
    for (let i=0; i < data_json.length; i++) {
        data.push(data_json[i].deaths)
    }
    console.log(data);
    return data
}
function getStateNames(data_json) {
    let data = [];
    for (let i=0; i < data_json.length; i++) {
        data.push(data_json[i].state)
    }
    console.log(data);
    return data
}

function getCountryNames(data_json) {
    let data = [];
    for (let i=0; i < data_json.length; i++) {
        data.push(data_json[i].country)
    }
    console.log(data);
    return data
}